//This is a hello world program.
#include<stdio.h>
void main()
{/*Comments are not allowed here.
They must be removed.*/
int a=0,b=1,c;
char d;
printf("Hello World\n");
}
