#include<stdio.h>
void main()
{
int a=0,b=1,c;
char d;
printf("Hello World\n");
}
