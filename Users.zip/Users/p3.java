import java.util.Scanner;
import java.util.regex.Pattern;
public class p3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the  non terminals");
        String[] nonterm=sc.next().split(",");
        int nt=nonterm.length;
        System.out.println("Enter the terminals");
        String[] term=sc.next().split(",");
        int t=term.length;
        char[][] first=new char[nt][t];
        char[][] follow=new char[nt][t];
        String[][] prod=new String[nt][t];
        String[][] parTab=new String[nt][t];
        for(int i=0;i<nt;i++)
            for(int j=0;j<t;j++){
                parTab[i][j]=prod[i][j]="-";
                first[i][j]=follow[i][j]='-';
            }
        for(int i=0;i<nt;i++){
            System.out.print(nonterm[i]+"->");
            String[] production=sc.next().split(Pattern.quote("|"));
            for(int j=0;j<production.length;j++){
                prod[i][j]=production[j];
            }
            System.out.print("First("+nonterm[i]+")->");
            String[] frst=sc.next().split(",");
            for(int j=0;j<frst.length;j++)
                first[i][j]=frst[j].charAt(0);
            System.out.print("Follow("+nonterm[i]+")->");
            String[] foll=sc.next().split(",");
            for(int j=0;j<foll.length;j++)
                follow[i][j]=foll[j].charAt(0);
        }
        for(int i=0;i<nt;i++){
            for(int j=0;j<t;j++){
                if(prod[i][j]!="-"&&prod[i][j]!="@"){
                    if(Character.isLowerCase(prod[i][j].charAt(0))){
                        parTab[i][coord(prod[i][j].charAt(0),term)]=prod[i][j];
                    }
                    else{
                        int x=coord(prod[i][j].charAt(0),nonterm);
                        for(int k=0;k<first[x].length&&first[x][k]!='-';k++)
                            parTab[i][coord(first[x][k],term)]=prod[i][j];
                    }
                }
                else if(prod[i][j]=="@"){
                    for(int k=0;k<first[i].length&&first[i][k]!='-';k++)
                        parTab[i][coord(first[i][k],term)]=prod[i][j];
                }
            }
        }
        display(parTab,nonterm,term, nt, t);
        char[] s1=new char[10];int top1=-1;
        char[] s2=new char[10];int top2=-1;
        s1[++top1]=s2[++top2]='$';
        s1[++top1]=nonterm[0].charAt(0);
        System.out.println("Enter the string for parsing");
        String temp=sc.next();
        for(int i=temp.length()-1;i>=0;i--){
            s2[++top2]=temp.charAt(i);
        }
        while(s1[top1]!='$'&&s2[top2]!='$'){
            for(int i=top1;i>=0;i--)
                System.out.print(s1[i]);
            System.out.print("\t");
            for(int i=top2;i>=0;i--)
                System.out.print(s2[i]);
            System.out.print("\t");
            if(Character.isUpperCase(s1[top1])){
                String sub=parTab[coord(s1[top1],nonterm)][coord(s2[top2],term)];
                System.out.println("Substitute "+s1[top1]+"->"+sub);
                --top1;
                for(int i=sub.length()-1;i>=0;i--){
                    s1[++top1]=sub.charAt(i);
                }
                while(s1[top1]=='@')
                    --top1;
            }
            else if(s1[top1]==s2[top2]){
                System.out.println("Reduce "+s1[top1]);
                --top1;--top2;
            }
            else if(s1[top1]=='@'){
                while(s1[top1]=='@')
                    --top1;
            }
            else{
                System.out.println("Reject");
                break;
            }
        }
        sc.close();
    }
    public static int coord(char a,String[] b){
        for(int i=0;i<b.length;i++)
            if(b[i].charAt(0)==a)
                return i;
        return 0;
    }
    public static void display(String[][] parTab,String[] nonterm,String[] term,int nt,int t){
        System.out.println();
        System.out.println("LL(1) Parsing Table");
        String[][] Table=new String[nt+1][t+1];
        Table[0][0]="-";
        for(int i=1;i<t+1;i++)
            Table[0][i]=term[i-1];
        for(int i=1;i<nt+1;i++)
            Table[i][0]=nonterm[i-1];
        for(int i=1;i<nt+1;i++)
            for(int j=1;j<t+1;j++)
                if(parTab[i-1][j-1]=="-")
                    Table[i][j]="-";
                else
                Table[i][j]=nonterm[i-1]+"->"+parTab[i-1][j-1];
        for(int i=0;i<nt+1;i++){
            for(int j=0;j<t+1;j++){
                System.out.print(Table[i][j]+"\t");
            }
            System.out.println();
        }
    }
}
