import java.util.Scanner;
import java.util.regex.Pattern;

public class p5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        while(true){
            String command=sc.next();int mode=0;
            String[] sides=command.split("=");
            if(sides[1].contains("+")){
                String[] terms=sides[1].split(Pattern.quote("+"));mode=0;
                System.out.println(terms[0]+","+terms[1]);
                Load("R3,R2",terms);
                Oper(mode,"R3","R2","R1");
                Store(sides,"R1");
            }
            else if(sides[1].contains("*")){
                String[] terms=sides[1].split(Pattern.quote("*"));mode=1;
                System.out.println(terms[0]+","+terms[1]);
            }
            else if(sides[1].contains("-")){
                String[] terms=sides[1].split(Pattern.quote("-"));mode=2;
                System.out.println(terms[0]+","+terms[1]);
            }
            else{
                
            }
        }
    }
    public static void Load(String a,String[] c){
        String[] b=a.split(Pattern.quote(","));
        System.out.println("LOAD "+b[0]+","+c[0]);
        System.out.println("LOAD "+b[1]+","+c[1]);
    }
    public static void Oper(int mode,String a,String b,String c){
        switch(mode){
            case 0:System.out.println("ADD "+" "+a+","+b+","+c);break;
        }
    }
    public static void Store(String[] a,String b){
        System.out.println("STORE "+a[0]+","+b);
    }
}
