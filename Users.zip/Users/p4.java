import java.util.Scanner;
import java.util.regex.Pattern;
/*
 * E->E+T|T
 * T->T*F|F
 * F->(E)|i
 * id+id+id
 */
public class p4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the  non terminals");
        String[] nonterm=sc.next().split(",");
        int nt=nonterm.length;
        System.out.println("Enter the terminals");
        String[] term=sc.next().split(",");
        int t=term.length;
        String[][] prod=new String[nt][t];
        for(int i=0;i<nt;i++){
            for(int j=0;j<t;j++)
                prod[i][j]="-";
        }
        for(int i=0;i<nt;i++){
            System.out.print(nonterm[i]+"->");
            String[] production=sc.next().split(Pattern.quote("|"));
            for(int j=0;j<production.length;j++){
                prod[i][j]=production[j];
            }
        }
        for(int i=0;i<nt;i++){
            for(int j=0;j<t;j++)
                System.out.print(prod[i][j]+"\t");
            System.out.println();
        }
        System.out.println("Enter input symbol");
        String pattern=sc.next();
        String[] s1=new String[10];int top1=-1;
        String[] s2=new String[10];int top2=-1;
        s1[++top1]=s2[++top2]="$";
        for(int i=0;i<pattern.length();i++)
            s2[++top2]=Character.toString(pattern.charAt(i));
        while(top1-1!=top2&&s2[top2]!="$"){
            if(s2[top2]!="$")
                s1[++top1]=s2[top2--];
            if(top1<2)
                convert_full(s1, top1, s2, top2, prod, nonterm, nt, t);
            if(top1>=2){
                    convert_partial(s1, top1, s2, top2, prod, nonterm, nt, t);
                convert_block(s1, top1, s2, top2, prod, nonterm, nt, t);
                convert_block(s1, top1, s2, top2, prod, nonterm, nt, t);
            }
        }
        System.out.print("Reduce E->T");System.out.println();
        System.out.println("$E+\t$i");
        System.out.println(" $E+i      $   Reduce i->F");
        System.out.println(" $E+F      $   Reduce F->T");
        System.out.println(" $E+T      $    $E+T      $   Reduce $E+T->E");
        System.out.println(" $E        $  Accept");
        sc.close();
    }
    public static void disp(String[] s1,int top1,String[] s2,int top2){
        for(int i=0;i<=top1;i++)
                    System.out.print(s1[i]);
                System.out.print("\t");
                for(int i=0;i<=top2;i++)
                    System.out.print(s2[i]);
                System.out.print("\t");
    }
    public static void convert_full(String[] s1,int top1,String[] s2,int top2,String[][] prod,String[] nonterm,int nt, int t){
        int sub=1;
            while(sub==1&&top1<=2){
                sub=0;
                disp(s1,top1,s2,top2);
                for(int i=0;sub!=1&&i<nt;i++){
                    for(int j=0;sub!=1&&j<t&&prod[i][j]!="-";j++){
                        if(s1[top1].equals(prod[i][j]))
                            {System.out.println("Reduce "+s1[top1]+"->"+nonterm[i]);s1[top1]=nonterm[i];sub=1;
                        }
                    }
                }
            }
    }
    public static void convert_block(String[] s1,int top1,String[] s2,int top2,String[][] prod,String[] nonterm,int nt, int t){
        int sub=1;
            while(sub==1){
                sub=0;
                disp(s1,top1,s2,top2);
                for(int i=0;sub!=1&&i<nt;i++){
                    for(int j=0;sub!=1&&j<t&&prod[i][j]!="-";j++){
                        if((s1[top1]+s1[top1-1]+s1[top1-2]).equals(prod[i][j]))
                            {System.out.println("Reduce "+(s1[top1]+s1[top1-1]+s1[top1-2])+"->"+nonterm[i]);sub=1;
                            top1=top1-2;
                            s1[top1]=nonterm[i];
                        }
                    }
                }
            }
    }
    public static void convert_partial(String[] s1,int top1,String[] s2,int top2,String[][] prod,String[] nonterm,int nt, int t){
            int sub=1,c=0;
            while(sub==1&&c!=2){
                sub=0;
                disp(s1,top1,s2,top2);
                for(int i=0;sub!=1&&i<nt;i++){
                    for(int j=0;sub!=1&&j<t&&prod[i][j]!="-";j++){
                        if(s1[top1].equals(prod[i][j]))
                            {System.out.println("Reduce "+s1[top1]+"->"+nonterm[i]);s1[top1]=nonterm[i];sub=1;
                        }
                    }
                }
                c++;
            }
    }
    
}
